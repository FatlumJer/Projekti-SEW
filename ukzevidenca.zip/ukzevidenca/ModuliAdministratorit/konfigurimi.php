<?php
    $conn = mysqli_connect("localhost","root","","ukz_evidenca") 
	or die('Gabim ne lidhje!');
?>